https://habr.com/ru/companies/infowatch/articles/337084/
https://users.cs.jmu.edu/buchhofp/forensics/formats/pkzip.html
https://www.opennet.ru/docs/RUS/bogatyrev/gl_4_1.html#b2
EOF это 0xffffffff