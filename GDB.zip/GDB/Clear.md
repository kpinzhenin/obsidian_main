Удаление точки останова, catchpoint и наверно watchpoint.
удаление привязанного к строке
```c
(gdb)clear 5
Deleted breakpoints 1
```
удаление привязанного к "символу" - функции.
```c
(gdb)clear foo
Deleted breakpoints 1
```