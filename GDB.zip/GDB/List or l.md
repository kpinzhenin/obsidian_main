Выводит исходный код программы
```c
(gdb) l
1	#include <stdio.h>
2	
3	int main(void)
4	{
5		int x;
6		int a = x;
7		int b = x;	
8		int c = a + b;
9		printf("c = %d \n", c);
10		return 0;
}
```