Информация о текущем состоянии от текущих точках остановки
```c
(gdb) info b
um     Type           Disp Enb Address            What
1       breakpoint     keep n   0x0000000000001155 in main at tst.c:6
```