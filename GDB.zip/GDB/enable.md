разрешение точек останова
включение всех
```c
(gdb) enable b
(gdb) info b
Num     Type           Disp Enb Address            What
1       breakpoint     keep y   0x0000000000001155 in main at tst.c:6
```
включение выбранных (для выбора используется порядковый номер)
```c

```